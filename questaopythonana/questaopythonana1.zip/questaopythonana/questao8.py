a = int(input('diga sua idade:'))
if a >= 25:
    if a <= 60:
        print('entre vinte cinco e sessenta anos')
    else:
        print('maior que sessenta anos')
else:
    print('menor que vinte cinco anos')