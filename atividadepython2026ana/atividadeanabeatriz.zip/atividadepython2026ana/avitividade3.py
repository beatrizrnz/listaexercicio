import math
raio = float(input("diga o valor do raio: "))
area = math.pi * (raio ** 2)
print(f"A area da circunferência e: {area:.2f}")