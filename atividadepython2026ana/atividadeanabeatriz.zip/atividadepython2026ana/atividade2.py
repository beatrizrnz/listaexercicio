idade = int(input("Qual sera sua idade no ano atual? "))
ano_atual = 2026  
ano_nascimento = ano_atual - idade
print(f"Você nasceu em: {ano_nascimento}")


