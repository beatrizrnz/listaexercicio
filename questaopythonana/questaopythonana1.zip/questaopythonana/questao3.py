opcao = int(input("digite um numero:"))
while opcao != 1 and opcao != 2:
    print("opcao invalida")
    if opcao == 1           :
        print("continuando o programa")
    if opcao == 2:
        print("saindo do programa")
    else:
        print("opcao invalida")
